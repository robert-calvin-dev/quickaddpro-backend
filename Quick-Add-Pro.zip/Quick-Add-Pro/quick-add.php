<?php
/**
 * Plugin Name: Quick Add Pro
 * Plugin URI: https://yourdomain.com/quick-add
 * Description: Quick Add is a powerful WooCommerce companion that allows you to create products quickly from a custom admin screen, with SKU and ID automation. Pro version includes SEO, social, and schema fields.
 * Version: 1.0
 * Author: Robert Calvin
 * Author URI: https://yourdomain.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-add
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_menu_page('Quick Add', 'Quick Add', 'manage_options', 'quick-add', 'render_interactive_product_form_page', 'dashicons-plus-alt', 56);
});

function render_interactive_product_form_page() {
    echo do_shortcode('[interactive_product_form]');
}

add_filter('manage_product_posts_columns', function ($columns) {
    $columns['seo_keywords'] = 'Focus Keyword';
    $columns['seo_title'] = 'SEO Title';
    return $columns;
});

add_action('manage_product_posts_custom_column', function ($column, $post_id) {
    if ($column === 'seo_keywords') echo esc_html(get_post_meta($post_id, 'seo_keywords', true));
    if ($column === 'seo_title') echo esc_html(get_post_meta($post_id, 'seo_title', true));
}, 10, 2);


add_action('init', function () {
    add_shortcode('interactive_product_form', 'render_interactive_product_form');
});

function render_interactive_product_form() {
    ob_start();
    ?>
   <style>
 #product-form-wrapper {
            max-width: 100%;
            overflow-x: auto;
            padding: 20px;
        }
        #product-container {
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
  gap: 20px;
  padding-bottom: 40px;
}

.product-block {
  flex: 0 0 600px; /* fixed width */
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  background: #fff;
  box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}
        .product-block .seo-fields {
  margin-top: 20px;
  padding: 20px;
  border-top: 1px solid #ccc;
}

.product-block .seo-fields label {
  display: block;
  margin-bottom: 12px;
  font-weight: 500;
}

.product-block .seo-fields input[type="text"],
.product-block .seo-fields textarea,
.product-block .seo-fields input[type="url"] {
  width: 100%;
  padding: 10px;
  font-size: 14px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 6px;
}

.product-block .seo-fields button.upload_og_image {
  margin-top: 8px;
}

.product-block .seo-fields .quick-seo-field {
  margin-bottom: 16px;
}

        .form-grid {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
            gap: 20px;
        }
        .standard-fields, .pro-fields {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .inline-group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: center;
        }
        .inline-group label {
            flex: 1 1 22%;
            display: flex;
            align-items: center;
            justify-content: flex-start;
        }
        label {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            width: 100%;
        }
        input[type="text"], input[type="number"], select, textarea {
            flex: 1;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea[name="long_description"] {
            height: 200px;
        }
        textarea {
            resize: vertical;
        }
        .pro-fields {
            background: #240046;
            color: #fff;
            padding: 16px;
            border-radius: 8px;
        }
        .pro-fields input,
        .pro-fields textarea {
            background: #eee;
            color: #333;
        }
        .pro-fields h3 {
            color: gold;
            text-align: center;
        }
        .form-actions {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
        .grouped-products-wrapper {
            width: 100%;
        }

        select {
            width: 100%;
        }
        .form-actions button,
        #add-product {
            background: #a5e4e1;
            padding: 8px 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
    </style>
    <div id="product-form-wrapper">
        <button id="add-product">Add Product</button>
        <br>
        <br>
        <form id="product-form">
            <div id="product-container"></div>
            <div class="form-actions">
            
                <button type="submit">Submit</button>
            </div>
        </form>
 
    <template id="product-template">
        <div class="product-block">
            <div class="form-grid">
                <div class="standard-fields">
                    <input placeholder="Name"  type="text" name="product_name[]">
                    <div class="inline-group">
                            <select name="product_type[]">
                                <option value="simple">Simple</option>
                                <option value="variable">Variable</option>
                                <option value="grouped">Grouped</option>
                                <option value="external">External/Affiliate</option>
                                <option value="subscription">Subscription</option>
                            </select>
                            <div class="external-url-wrapper" style="display:none;">
                        <label>External Product URL <input type="url" name="external_url[]"></label>
   
                    </div>
                    <div class="grouped-products-wrapper" style="display:none;">
                        
                        <select multiple name="grouped_children[]">
                            <!-- dynamically populated by JS -->
                        </select>
                 
                </div>
                        <input placeholder="Price"  type="number" name="price[]" step="0.01">
                        <input placeholder="Categories"  type="text" name="category[]">
                        <input placeholder="Tags"  type="text" name="tags[]">
                    </div>
                    <div class="inline-group">
                        <label><input type="checkbox" name="featured[]"> Feature</label>
                        <label><input type="checkbox" name="in_stock[]"> In Stock?</label>
                        <label><input type="checkbox" name="stock_managed[]"> Mng Stock</label>
                        <label><input type="checkbox" class="schedule-sale-checkbox"> Schedule Sale</label>
                        <input placeholder="# in stock"  type="number" name="stock_qty[]">
                        <div class="sale-fields" style="display:none;">
         <input placeholder="Sale Price"  type="number" name="sale_price[]" step="0.01" />
      <input type="date" name="sale_start[]" /> --
     <input type="date" name="sale_end[]" />
    </div>
                    </div>
                    <input type="button" class="upload_image_button button" value="Upload Image" />
                   <textarea placeholder="Short Description "  name="short_description[]"></textarea>
                     <textarea placeholder="Long Description"  name="long_description[]"></textarea>
                     <div class="attribute-container"></div>
<button type="button" class="add-attribute-btn">+ Add Product Attribute</button>
<div class="variable-info" style="display:none;">
                        <p style="color: #555; font-style: italic;">Quick Add Variations are coming soon. For now, manage variations in the regular WordPress product editor.</p>
                    </div>


                    <div class="seo-fields">
  <h4>SEO Fields (Pro Only)</h4>
  <label>SEO Title
    <input type="text" name="seo_title[]" placeholder="Enter SEO title" />
  </label>
  <label>SEO Description
    <textarea name="seo_description[]" rows="2" placeholder="SEO description"></textarea>
  </label>
  <label>Focus Keywords (comma-separated)
    <input type="text" name="seo_keywords[]" placeholder="keyword1, keyword2" />
  </label>
  <label>OG Title
    <input type="text" name="seo_og_title[]" placeholder="OpenGraph title" />
  </label>
  <label>OG Description
    <input type="text" name="seo_og_description[]" placeholder="OpenGraph description" />
  </label>
  <label>OG Image URL
    <input type="text" name="seo_og_image[]" id="seo_og_image" />
    <button type="button" class="button upload_og_image">Upload Image</button>
  </label>
  <p class="quick-seo-field">
  <label>
    <input type="checkbox" name="include_schema[]" value="1" />
    Inject Product Schema JSON
  </label>
</p>
  
            </div>
        </div>
            </div>
    
    </template>
    <?php
    wp_enqueue_media();
    wp_enqueue_script('ipf-script', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], null, true);
    wp_localize_script('ipf-script', 'ipf_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ipf_nonce'),
        'grouped_products' => get_posts([
    'post_type' => 'product',
    'numberposts' => -1,
    'post_status' => 'publish',
    'meta_query' => [[
        'key' => '_product_type',
        'value' => 'simple'
    ]]
])
    ]);
    return ob_get_clean();
}

add_action('add_meta_boxes', function () {
    add_meta_box('quick_add_pro_seo', 'Quick Add Pro SEO', 'render_quick_add_pro_seo_box', 'product', 'normal', 'default');
});

function render_quick_add_pro_seo_box($post) {
    $meta = fn($key) => get_post_meta($post->ID, $key, true);

    $focus_keyword   = esc_attr($meta('seo_keywords'));
    $seo_title       = esc_attr($meta('seo_title'));
    $seo_description = esc_textarea($meta('seo_description'));
    $og_title        = esc_attr($meta('seo_og_title'));
    $og_description  = esc_attr($meta('seo_og_description'));
    $og_image        = esc_attr($meta('seo_og_image'));
    $schema_data     = esc_textarea($meta('schema_data'));
    $include_schema  = $meta('include_schema') === '1' ? 'checked' : '';
    $schema_display  = $include_schema ? 'block' : 'none';

    echo <<<HTML
    <div id="quick-add-seo-fields">
        <p class="quick-seo-field" style="margin-bottom:12px;"><label>Focus Keyword<br>
        <input type="text" name="seo_keywords" value="{$focus_keyword}" style="width:100%;" /></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;"><label>SEO Title<br>
        <input type="text" name="seo_title" value="{$seo_title}" style="width:100%;" /></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;"><label>Meta Description<br>
        <textarea name="seo_description" rows="2" style="width:100%;">{$seo_description}</textarea></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;"><label>Social Media Title<br>
        <input type="text" name="seo_og_title" value="{$og_title}" style="width:100%;" /></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;"><label>Social Media Description<br>
        <input type="text" name="seo_og_description" value="{$og_description}" style="width:100%;" /></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;"><label>Social Media Image URL<br>
        <input type="text" name="seo_og_image" id="seo_og_image" value="{$og_image}" style="width:100%;" />
        <button type="button" class="button upload_og_image">Select Image</button></label></p>

        <p class="quick-seo-field" style="margin-bottom:12px;">
            <label><input type="checkbox" name="include_schema" id="include_schema" value="1" {$include_schema}>
            Inject Product Schema JSON</label>
        </p>

        <div id="schema_wrapper" style="margin-top:10px; display: {$schema_display};">
            <label>Product Schema JSON<br>
            <textarea name="schema_data" rows="6" style="width:100%;">{$schema_data}</textarea></label>
        </div>
    </div>
HTML;
}



add_action('wp_ajax_ipf_save_product', 'ipf_save_product');
function ipf_save_product() {
    check_ajax_referer('ipf_nonce', 'nonce');

    $names = $_POST['product_name'] ?? [];

    if (!is_array($names)) {
        wp_send_json_error('Invalid submission');
    }

    $created = [];
    foreach ($names as $index => $name) {
        $sku = strtoupper(substr($name, 0, 2) . substr($name, -2));
        $id = null;
        for ($i = 1; $i <= 1000; $i++) {
            $candidate = str_pad(rand(1, 1000), 4, '0', STR_PAD_LEFT);
            if (!get_page_by_title($candidate, OBJECT, 'product')) {
                $id = $candidate;
                break;
            }
        }

        $post = [
            'post_title' => sanitize_text_field($name),
            'post_content' => sanitize_textarea_field($_POST['long_description'][$index]),
            'post_excerpt' => sanitize_text_field($_POST['short_description'][$index] ?? ''),
            'post_status' => 'publish',
            'post_type' => 'product',
        ];

        $product_id = wp_insert_post($post);
        if (!$product_id) continue;

        update_post_meta($product_id, 'seo_title', $_POST['seo_title'][$index]);
        update_post_meta($product_id, 'seo_description', $_POST['seo_description'][$index]);
        update_post_meta($product_id, 'seo_keywords', $_POST['seo_keywords'][$index]);
        update_post_meta($product_id, 'seo_og_title', $_POST['seo_og_title'][$index]);
        update_post_meta($product_id, 'seo_og_description', $_POST['seo_og_description'][$index]);
        update_post_meta($product_id, 'seo_og_image', $_POST['seo_og_image'][$index]);

        // Handle schema injection
        $include_schema = isset($_POST['include_schema'][$index]) ? '1' : '0';
        update_post_meta($product_id, 'include_schema', $include_schema);

        if ($include_schema === '1') {
            $schema = [
                "@context" => "https://schema.org",
                "@type" => "Product",
                "name" => $_POST['product_name'][$index] ?? '',
                "image" => $_POST['product_image'][$index] ?? '',
                "description" => $_POST['long_description'][$index] ?? '',
                "sku" => $sku,
                "brand" => ["@type" => "Brand", "name" => "Quick Add Pro"]
            ];
            update_post_meta($product_id, 'schema_data', json_encode($schema, JSON_PRETTY_PRINT));
        }

        update_post_meta($product_id, '_price', wc_format_decimal($_POST['price'][$index]));
        update_post_meta($product_id, '_regular_price', wc_format_decimal($_POST['price'][$index]));
        update_post_meta($product_id, '_sku', $sku);
        update_post_meta($product_id, '_stock', intval($_POST['stock_qty'][$index] ?? 0));
        update_post_meta($product_id, '_manage_stock', !empty($_POST['stock_managed'][$index]) ? 'yes' : 'no');
        update_post_meta($product_id, '_featured', !empty($_POST['featured'][$index]) ? 'yes' : 'no');
        
        update_post_meta($product_id, '_stock_status', !empty($_POST['in_stock'][$index]) ? 'instock' : 'outofstock');

        if (!empty($_POST['sale_price'][$index])) {
            update_post_meta($product_id, '_sale_price', wc_format_decimal($_POST['sale_price'][$index]));
        }
        if (!empty($_POST['sale_start'][$index])) {
            update_post_meta($product_id, '_sale_price_dates_from', strtotime($_POST['sale_start'][$index]));
        }
        if (!empty($_POST['sale_end'][$index])) {
            update_post_meta($product_id, '_sale_price_dates_to', strtotime($_POST['sale_end'][$index]));
        }

        // Handle attributes
        if (!empty($_POST['attribute_name'][$index])) {
            $attributes = [];
            foreach ($_POST['attribute_name'][$index] as $attr_index => $attr_name) {
                $attr_slug = wc_sanitize_taxonomy_name($attr_name);
                $values = array_map('trim', explode('|', $_POST['attribute_values'][$index][$attr_index]));

                $attributes[$attr_slug] = [
                    'name' => $attr_name,
                    'value' => implode('|', $values),
                    'is_visible' => 1,
                    'is_variation' => !empty($_POST['attribute_variation'][$index][$attr_index]) ? 1 : 0,
                    'is_taxonomy' => 0
                ];
            }
            update_post_meta($product_id, '_product_attributes', $attributes);
        }

        $type = sanitize_text_field($_POST['product_type'][$index]);
        wp_set_object_terms($product_id, $type, 'product_type', false);

        if ($type === 'external') {
            update_post_meta($product_id, '_product_url', esc_url_raw($_POST['external_url'][$index] ?? ''));
        }

        if ($type === 'grouped') {
            $grouped_ids = array_map('intval', $_POST['grouped_children'][$index] ?? []);
            update_post_meta($product_id, '_children', $grouped_ids);
        }

        if (!empty($_POST['category'][$index])) {
            $cats = array_map('trim', explode(',', $_POST['category'][$index]));
            $cat_ids = [];
            foreach ($cats as $cat_name) {
                $term = term_exists($cat_name, 'product_cat');
                if (!$term) {
                    $term = wp_insert_term($cat_name, 'product_cat');
                }
                if (!is_wp_error($term)) {
                    $cat_ids[] = intval($term['term_id']);
                }
            }
            if (!empty($cat_ids)) {
                wp_set_object_terms($product_id, $cat_ids, 'product_cat');
            }
        }

        if (!empty($_POST['tags'][$index])) {
            wp_set_post_terms($product_id, explode(',', sanitize_text_field($_POST['tags'][$index])), 'product_tag');
        }

        if (!empty($_POST['product_image'][$index])) {
            $image_url = esc_url_raw($_POST['product_image'][$index]);
            $attachment_id = attachment_url_to_postid($image_url);
            if ($attachment_id) {
                set_post_thumbnail($product_id, $attachment_id);
            }
        }

        $created[] = $product_id;
    }

    if (!empty($created)) {
        wp_send_json_success(['created' => $created]);
    } else {
        wp_send_json_error('No products created');
    }
}
add_action('save_post_product', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['include_schema'])) {
        update_post_meta($post_id, 'include_schema', '1');
    } else {
        delete_post_meta($post_id, 'include_schema');
    }
    

    foreach ([
        'seo_title',
        'seo_description',
        'seo_keywords',
        'seo_og_title',
        'seo_og_description',
        'seo_og_image',
        'schema_data'
    ] as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }
});


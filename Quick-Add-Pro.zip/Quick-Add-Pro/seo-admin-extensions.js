jQuery(document).ready(function ($) {
  $('.product-block').each(function () {
      const block = $(this);

      function updateOGPreview() {
          const title = block.find('input[name="seo_og_title[]"]').val();
          const desc = block.find('input[name="seo_og_description[]"]').val();
          const image = block.find('input[name="seo_og_image[]"]').val();

          // Add preview in block
          if (!block.find('.og-preview').length) {
              block.append(`
                <div class="og-preview" style="margin-top:10px;">
                  <strong>OG Preview</strong>
                  <p id="og-preview-title"></p>
                  <p id="og-preview-desc"></p>
                  <img id="og-preview-img" style="max-width:100px;" />
                </div>`);
          }

          block.find('#og-preview-title').text(title);
          block.find('#og-preview-desc').text(desc);
          block.find('#og-preview-img').attr('src', image);
      }

      block.find('input[name="seo_og_title[]"], input[name="seo_og_description[]"], input[name="seo_og_image[]"]').on('input', updateOGPreview);
      updateOGPreview();
  });
});

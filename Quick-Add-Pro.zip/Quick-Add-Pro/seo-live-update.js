jQuery(document).ready(function ($) {
  $('.product-block').each(function () {
      const block = $(this);
      const scoreBox = block.find('#live-seo-score');

      const getContent = () => {
          const title = block.find('input[name="seo_title[]"]').val() || '';
          const desc = block.find('textarea[name="seo_description[]"]').val() || '';
          const focus = (block.find('input[name="seo_keywords[]"]').val() || '').toLowerCase();
          const words = (title + ' ' + desc).toLowerCase().split(/\s+/);
          const totalWords = words.length;

          let score = 0;
          if (title) score += 10;
          if (desc) score += 10;
          if (focus) {
              if (title.includes(focus)) score += 10;
              if (desc.includes(focus)) score += 10;
          }

          const keywordList = focus.split(',').map(k => k.trim()).filter(Boolean);
          keywordList.forEach(k => {
              const count = words.filter(word => word === k).length;
              const density = totalWords ? (count / totalWords) * 100 : 0;
              if (density >= 0.5 && density <= 2.5) score += 10;
          });

          const color = score >= 70 ? 'green' : score >= 40 ? 'orange' : 'red';
        
      };

      block.find('input, textarea').on('input', getContent);
      getContent();
  });
});
